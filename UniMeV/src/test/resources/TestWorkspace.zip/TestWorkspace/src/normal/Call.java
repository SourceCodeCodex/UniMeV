package normal;

public class Call {

	public void call1(A a)
	{
		a.m();
	}
	public void call2(B a)
	{
		a.m();
	}
}
