package normal;

public class B extends A{

}
