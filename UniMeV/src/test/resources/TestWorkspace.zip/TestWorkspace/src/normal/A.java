package normal;

public class A {

	public void m()
	{
		
	}
}
