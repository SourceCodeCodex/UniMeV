package exceptions;

public class B {

	static void m()
	{
		
	}
}
