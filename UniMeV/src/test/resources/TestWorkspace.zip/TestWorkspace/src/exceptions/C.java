package exceptions;

public class C {

	public void m()
	{
		
	}
}
