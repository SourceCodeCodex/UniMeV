package exceptions;

public class D {

}
