package exceptions;

public class A {

	private void m()
	{
	}

}
