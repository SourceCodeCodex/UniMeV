package normal2;

public class A {

	public void m()
	{
		
	}
}
