package normal2;

public class Call {

	public void call1(A a)
	{
		a.m();
	}
	
	public void call2(B a)
	{
		a.m();
	}
	
	public void call3(C a)
	{
		a.m();
	}
}
