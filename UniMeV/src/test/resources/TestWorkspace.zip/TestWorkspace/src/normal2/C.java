package normal2;

public class C extends B{

	public void m()
	{
		
	}
}
