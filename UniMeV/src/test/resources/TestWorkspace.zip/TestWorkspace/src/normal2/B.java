package normal2;

public class B extends A{

	public void m()
	{
		
	}
}
